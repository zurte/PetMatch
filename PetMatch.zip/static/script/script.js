document.getElementById("registrar").addEventListener("click", function() {
    window.location.href = "/registrar";
    
    console.log("Botão clicado!");
});